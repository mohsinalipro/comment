export const elements = {
    mainCommentTextbox:  document.querySelector('.main_comment__box'),
    commentTextbox: document.querySelector('.comment__box'),
    commentList: document.querySelector('.comment__list'),
    viewPreviousButton: document.querySelector('.view_previous_comments-btn'),
};